<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <!-- Meta tags Obrigatórias -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <title>EXERCICIO 1</title>
  </head>
  <body>
   <!-- ------------------------------------- -->
    <h3>Exercicio 1</h3>
	   <p> Criar um programa em que o usuário digite um 
	   valor para variável A, um valor para variável B,
	   troque os valores das variáveis de forma que a A
	   tenha o valor de B e B tenha o valor de A. Apresentar os valores de A e B.</p>
  
   	<form action="./php/exerc1.php" method="POST">
   	
   	<label for="varA">Variavel A:</label>
        <input type="text" placeholder="Variável A" name="varA" />
        
    <label for="varB">Variavel B:</label>
        <input type="text" placeholder="Variável B" name="varB" />
  
    <button type="submit"> Enviar</button>

	</form>
	  
	<br>
	  <hr>
	<br>
	 <!-- ------------------------------------- -->  
	  
	  <h3>Exercicio 2</h3>
	  	<p>2 - criar um programa em que o usuário digite uam quantidade de dias e seja exigido o total em Anos (s), mês (es) e dias (s). Considerar o ano com 365 dias e um mês com 30 dias.<p/>
	  
	  <form action="./php/exerc2.php" method="POST">
   	
		<label for="dias">Digite quantidade de dias</label>
			<input type="text" placeholder="Quantidade de dias" name="dias" />

		<button type="submit"> Enviar</button>

	</form>

	<br>
	  <hr>
	<br>
 <!-- ------------------------------------- -->	  
	  
	  <h3>Exercicio 3</h3>
	  	<p>3 - Criar um programa que lê o salário mensal atual de um funcionário e o percentual de reajuste. Calcular e escrever o valor do novo salário.<p/>
	  
	  <form action="./php/exerc3.php" method="POST">
   	
		<label for="salario">Digite seu salário:</label>
        <input type="text" placeholder="Digite seu salário" name="sal" />
        <br>
    <label for="reajuste">Digite o percentual de reajuste:</label>
        <input type="text" placeholder="reajuste" name="reaj" />
		  <br>
		<button type="submit"> Enviar</button>

	</form>

	  
	<br>
	  <hr>
	<br>
	 <!-- ------------------------------------- -->  
	  
	  <h3>Exercicio 4</h3>
	  	<p>4 - Criar um programa de uma equação do segundo grau.<p/>
	  	<p>equação: ax² + bx + c = 0, onde o usuário precisará digitar os termos (digitando se o termo é positivo ou negativo):</p>
	  	<p>a -> coeficiente principal</p>
	  	<p>b -> coeficiente secundário</p>
	  	<p>c -> termo independente</p>
	  <br>
	  <form action="./php/exerc4.php" method="POST">
   	
		<label for="a">Coeficiente principal (A):</label>
			<input type="text" placeholder="Coeficiente principal" name="a" />
			<br>
		<label for="b">Coeficiente secundário (B):</label>
			<input type="text" placeholder="Coeficiente secundário" name="b" />
			<br>		
		<label for="c">Termo independente (C):</label>
			<input type="text" placeholder="Termo independente" name="c" />
			<br>
		<button type="submit"> Enviar</button>

	</form>

	<br>
	  <hr>
	<br>
 
	 <!-- ------------------------------------- -->  
	  
	  <h3>Exercicio 5</h3>
	  	<p>5 - Criar um programa que leia 5 valores e exiba o maior valor, o menor valor, o segundo maior valor e o segundo menor valor.</p>
	  <br>
	  <form action="./php/exerc5.php" method="POST">
   	
		<label for="var1">valor 1:</label>
			<input type="text" placeholder="valor 1" name="var1" />
			<br>
		<label for="var2">valor 2:</label>
			<input type="text" placeholder="valor 2" name="var2" />
			<br>
		<label for="var3">valor 3:</label>
			<input type="text" placeholder="valor 3" name="var3" />
			<br>
		<label for="var4">valor 4:</label>
			<input type="text" placeholder="valor 4" name="var4" />
			<br>
		<label for="var5">valor 5:</label>
			<input type="text" placeholder="valor 5" name="var5" />
			<br>
		<button type="submit"> Enviar</button>

	</form>

	<br>
	  <hr>
	<br>
	
		 <!-- ------------------------------------- -->  
	  
	  <h3>Exercicio 6</h3>
	  	<p>6 - Criar um programa que leia o nome de 2 times e o numero de gols marcados na partida (para cada time). Escrever o nome do vencedor. Caso não haja vencedor, deverá ser impressa a palavra EMPATE.<p/>
	  <br>
	  <form action="./php/exerc6.php" method="POST">
   	
		<label for="time1">Nome do primeiro time:</label>
			<input type="text" placeholder="1 time" name="ti1" />
			<br>
		<label for="time1G">Gols do primeiro time:</label>
			<input type="text" placeholder="Gols 1 time" name="ti1g" />
			<br>		
		<label for="time2">Nome do segundo time:</label>
			<input type="text" placeholder="2 time" name="ti2" />
			<br>
		<label for="time1G">Gols do segundo time:</label>
			<input type="text" placeholder="Gols 2 time" name="ti2g" />
			<br>
		<button type="submit"> Enviar</button>

	</form>

<br>
	  <hr>
	<br>
	
		 <!-- ------------------------------------- -->  
	  
	  <h3>Exercicio 7</h3>
	  	<p>7 - Criar um programa que leia o valor numerico e seja exibido a menor quantidade de notas possiveis para o valor. Exemplo 587 - > 5 notas de 100, uma nota de 50, uma nota de 20, uma nota de 10, uma nota de 5 e uma nota de 2.<p/>
	  <br>
	  <form action="./php/exerc7.php" method="POST">
   	
		<label for="depos">Valor de deposito:</label>
			<input type="text" placeholder="Deposito" name="depos" />
			<br>
		<label for="retir">Retirada</label>
			<input type="text" placeholder="Retirada" name="retir" />
			<br>
		<button type="submit"> Enviar</button>

	</form>
  
  <br>
	  <hr>
	<br>
	
		 <!-- ------------------------------------- -->  
	  
	  <h3>Exercicio 8</h3>
	  	<p>8 - Criar um programa que leia o numero inicial e um numero final e apresente todas as tabuadas do intervalo.<p/>
	  <br>
	  <form action="./php/exerc8.php" method="POST">
   	
		<label for="tabini">valor inicial:</label>
			<input type="text" placeholder="inicial" name="tabini" />
			<br>
		<label for="tabfim">valor final</label>
			<input type="text" placeholder="final" name="tabfim" />
			<br>
		<button type="submit"> Enviar</button>

	</form>

  </body>
</html>