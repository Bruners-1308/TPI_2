<?php 

	$sal = (float) $_POST["sal"];
	$reaj = (float) $_POST["reaj"];

	$perc = (float) $reaj / 100;
	$novovalor = (float) $sal + ($sal * $perc);


	echo "Salario anterior: R$ ".number_format($sal,2,",",".");
	echo "<br/> Percentual de reajuste: $reaj% <br/>";
	echo "Novo Salário: R$ ".number_format($novovalor,2,",",".");


?>