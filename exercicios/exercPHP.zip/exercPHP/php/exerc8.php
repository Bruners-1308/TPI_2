<?php

$tabini = $_POST["tabini"];
$tabfim = $_POST["tabfim"];


while ($tabini <= tabfim){
$num = 0;
        while($num<=10){
            echo $num . " x " . $tab . " = " . ($num * $tab) . "<br>";
            $num++;
        }

}

?>