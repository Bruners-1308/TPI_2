<?php

	echo "A variável A agora é: " . $_POST["varB"]; 
	echo "<br/>";
	echo "A variável B agora é: " . $_POST["varA"]; 

?>
