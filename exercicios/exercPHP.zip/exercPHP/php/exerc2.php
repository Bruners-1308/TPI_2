<?php 

	$val = $_POST["dias"];

	$ano = (int) $val/365;
	$mes = (int) ($val % 365)/30;
	$dias = (int) ($val % 365) % 30;


	echo "$val dias são: <br/>";
	echo "Anos - ".number_format($ano,0);
	echo "<br/>";
	echo "Meses - ".number_format($mes,0);
	echo "<br/>";
	echo "Dias - ".number_format($dias,0);


?>