<?php

$ti1 = $_POST["ti1"];
$ti2 = $_POST["ti2"];
$ti1g = $_POST["ti1g"];
$ti2g = $_POST["ti2g"];


if ($ti1g > $ti2g){
	echo "Fim de jogo <br/>";
	echo $ti1."-".$ti1g." X ".$ti2g."-".$ti2."<br/>";
	echo $ti1." - VENCEDOR";
}elseif ($ti2g > $ti1g){
	echo "Fim de jogo <br/>";
	echo $ti1."-".$ti1g." X ".$ti2g."-".$ti2."<br/>";
	echo $ti2." - VENCEDOR";
}else {
	echo "Fim de jogo <br/>";
	echo $ti1."-".$ti1g." X ".$ti2g."-".$ti2."<br/>";
	echo " EMPATE ";
}

?>