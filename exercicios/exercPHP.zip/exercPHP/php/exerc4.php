<?php

$a = $_POST["a"];
$b = $_POST["b"];
$c = $_POST["c"];




$pot = pow($b,2);
$d = 4*$a*$c;


if($d < 0){
	$d *= -1;
	$res = $pot + $d;
	
	echo "Δ = b² - 4.a.c <br/>";
	echo "Δ = $b ² - 4.$a.$c <br/>";
	echo "Δ = $pot - - $d <br/>";
	echo "Δ = $res <br/>";
	
}else{
	$res = $pot - $d;
	
	echo "Δ = b² - 4.a.c <br/>";
	echo "Δ = $b ² - 4.$a.$c <br/>";
	echo "Δ = $pot - $d <br/>";
	echo "Δ = $res <br/>";
	
}
	
	echo "<br/> <br/> 2° passo: <br/> <br/>";
/* ------------------------------------------- */
	
	$etxt = "-b ± √Δ";
	$ftxt = "2 * a";

	echo "&nbsp; &nbsp; &nbsp; $etxt";
	echo "<br/> x = ------------------ <br/>";
	echo "&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $ftxt";

	if ($b < 0){
		
		if($res < 0){
			$l = $res *= -1;
			$i = sqrt($l);
		}else{
			$i = sqrt($res);
		}
		
		$g = "-($b)";
		$h = $b *= -1;
		$j = 2 * $a;
		
	echo "<br/><br/>";
	echo "&nbsp; &nbsp; &nbsp; &nbsp; $g  ± √ $res";
	echo "<br/> x = -------------------- <br/>";
	echo "&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 2 * $a";
	echo "<br/> <br/><br/>";
	echo "&nbsp; &nbsp; &nbsp; &nbsp; $h ± ";
	echo number_format($i,0);
	echo "<br/> x = -------------------- <br/>";
	echo "&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $j";
		
	$m = ($h + $i) / $j;
	$n = ($h - $i) / $j;
	
	echo "<br/><br/>";
	echo "&nbsp; &nbsp; &nbsp; &nbsp; $h + $i";
	echo "<br/> x' = -------------------- <br/>";
	echo "&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $j";
	echo "<br/> <br/>";
	echo "x' = ".number_format($m,0);;
	echo "<br/> <br/>";

	echo "<br/><br/>";
	echo "&nbsp; &nbsp; &nbsp; &nbsp; $h - $i";
	echo "<br/> x'' = -------------------- <br/>";
	echo "&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $j";
	echo "<br/> <br/>";
	echo "x'' = ".number_format($n,0);;
	echo "<br/> <br/>";
		
		
	}else{
		
		if($res < 0){
			$l = $res *= -1;
			$i = sqrt($l);
		}else{
			$i = sqrt($res);
		}
		
		$g = $b *= -1;
		$j = 2 * $a;
	echo "<br/><br/>";
	echo "&nbsp; &nbsp; &nbsp; &nbsp; $g  ± √ $res";
	echo "<br/> x = -------------------- <br/>";
	echo "&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 2 * $a";
	echo "<br/><br/>";
	echo "&nbsp; &nbsp; &nbsp; &nbsp; $g ± ";
	echo number_format($i,0);
	echo "<br/> x = -------------------- <br/>";
	echo "&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $j";
	
		
	$m = ($g + $i) / $j;
	$n = ($g - $i) / $j;
	
		
	echo "<br/><br/><br/>";
	echo "&nbsp; &nbsp; &nbsp; &nbsp; $g + ";
	echo number_format($i,0);
	echo "<br/> x' = -------------------- <br/>";
	echo "&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $j";
	echo "<br/><br/>";
	echo "x' = ".number_format($m,0);
	echo "<br/> <br/>";

	echo "<br/><br/>";
	echo "&nbsp; &nbsp; &nbsp; &nbsp; $g - ";
	echo number_format($i,0);
	echo "<br/> x'' = -------------------- <br/>";
	echo "&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $j";
	echo "<br/><br/>";
	echo "x'' = ".number_format($n,0);
	echo "<br/> <br/>";
		
	}


?>