<?php
/*
$var1 = $_POST["var1"];
$var2 = $_POST["var2"];
$var3 = $_POST["var3"];
$var4 = $_POST["var4"];
$var5 = $_POST["var5"];


$val = (int) array();
$val[0] = $_POST["var1"];
$val[1] = $_POST["var2"];
$val[2] = $_POST["var3"];
$val[3] = $_POST["var4"];
$val[4] = $_POST["var5"];


var_dump($val);



$res1 = max(explode(', $','$var1, $var2, $var3, $var4, $var5'));
echo $$res1;


	if (var1 > var2){
		$Mvar6 = $var1;
	}else {
		$Mvar6 = $var2;
	}

	if ($Mvar6 > $var3){
		$Mvar7 = $Mvar6;
	}else{
		$Mvar7 = $var3;
	}

	if ($Mvar7 > $var4){
		$Mvar8 = $Mvar7;
	}else{
		$Mvar8 = $var4;
	}

	if ($Mvar8 > $var5){
		$Mvar9 = $Mvar8;
	}else {
		$Mvar9 = $var5;
	}
*/



/*
	echo max($val[0],$val[1],$val[2],$val[3],$val[4]);
	echo "<br/>";
    echo min($val[0],$val[1],$val[2],$val[3],$val[4]);
	
	echo "<br/>";
	*/
	
$v = array($_POST["var1"],$_POST["var2"],$_POST["var3"],$_POST["var4"],$_POST["var5"]);

sort ($v);
foreach ($v as $n){
	echo "&nbsp; &nbsp;".$n;
}

echo "<br/> <br/>";
echo "O maior valor é: ".$v[4].", e o segundo maior é ".$v[3]."<br/>";
echo "<br/> <br/>";
echo "O menor valor é: ".$v[0].", e o segundo menor é ".$v[1]."<br/>";

?>