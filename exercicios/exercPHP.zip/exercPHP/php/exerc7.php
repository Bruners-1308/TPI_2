<?php

$depos = $_POST["depos"];
$retir = $_POST["retir"];

if($retir <= $depos){
  do {
    $not100 = (int) $retir/100;
	$rest = $retir%100;
  } while ($not100 > 100);

  do {
    $not50 = (int) $rest/50;
	$rest1 = $rest % 50;
  } while ($rest > 50);

  do {
    $not20 = (int) $rest1/20;
	$rest2 = $rest1 % 20;
  } while ($rest1 > 20);

  do {
    $not10 = (int) $rest2/10;
	$rest3 = $rest2 % 10;
  } while ($rest2 > 10);

  do {
    $not5 = (int) $rest3/5;
	$rest4 = $rest3 % 5;
  } while ($rest3 > 5);

  do {
    $not2 = (int) $rest4/2;
	$rest5 = $rest4 % 2;
  } while ($rest4 > 2);

  do {
    $not1 = (int) $rest5/1;
	$rest6 = $rest5 % 1;
  } while ($rest5 > 1);


echo "Valor em conta: R$ ".number_format($depos,2)."<br/>";
echo "Valor de retirada: R$ ".number_format($_POST["retir"],2)."<br/>";
echo "Foi retirado: <br/>";
echo number_format($not100,0)." notas de 100. <br/>";
echo number_format($not50,0)." notas de 50. <br/>";
echo number_format($not20,0)." notas de 20. <br/>";
echo number_format($not10,0)." notas de 10. <br/>";
echo number_format($not5,0)." notas de 5. <br/>";
echo number_format($not2,0)." notas de 2. <br/>";
echo number_format($not1,0)." notas de 1. <br/>";
}else{
	echo "SALDO INSUFICIENTE PARA RETIRADA!";
}


?>